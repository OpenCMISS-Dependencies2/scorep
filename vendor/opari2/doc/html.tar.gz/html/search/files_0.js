var searchData=
[
  ['opari2_5fregion_5finfo_2eh',['opari2_region_info.h',['../opari2__region__info_8h.html',1,'']]]
];

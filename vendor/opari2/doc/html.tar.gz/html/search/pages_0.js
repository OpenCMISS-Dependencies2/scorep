var searchData=
[
  ['basic_20usage',['Basic Usage',['../USAGE.html',1,'index']]]
];

var searchData=
[
  ['plugin_5fversion',['plugin_version',['../structSCOREP__Metric__Plugin__Info.html#a4f17bc4134f44442e43623bc7e587266',1,'SCOREP_Metric_Plugin_Info::plugin_version()'],['../structSCOREP__SubstratePluginInfo.html#a020b5e6467699babc5131a02b0a00333',1,'SCOREP_SubstratePluginInfo::plugin_version()']]],
  ['pre_5funify',['pre_unify',['../structSCOREP__SubstratePluginInfo.html#aa0a880d38e4411b67c5ce15dd4cabc22',1,'SCOREP_SubstratePluginInfo']]],
  ['profiling_5ftype',['profiling_type',['../structSCOREP__Metric__Properties.html#af4ce9e42e171a4d80802e6f03659c14b',1,'SCOREP_Metric_Properties']]],
  ['public_20type_20definitions_20and_20enums_20used_20in_20score_2dp',['Public type definitions and enums used in Score-P',['../group__public__types.html',1,'']]],
  ['performance_20analysis_20workflow_20using_20score_2dp',['Performance Analysis Workflow Using Score-P',['../workflow.html',1,'']]]
];
